<!-- @extends('layouts.app') -->

@section('content')
    <div class="container">
        <h2>{{ $book->title }}</h2>
        <p><strong>Author:</strong> {{ $book->author }}</p>
        <a href="{{url('/books')}}" class="btn btn-primary">Back</a>
    </div>
@endsection
