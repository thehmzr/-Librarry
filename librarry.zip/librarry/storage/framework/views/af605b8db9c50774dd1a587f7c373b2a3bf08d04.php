<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <style>
        body {
            background-color: aqua;
            padding: 200px;
        }
        .container {
            background-color: white;
            padding: 20px;
            border-radius: 10px;
        }
    </style>
</head>
<body>
<div class="container" style="background-image: url('<?php echo e(asset('images(1).jpg')); ?>');">
        <h1>About Us</h1>

        <p>
            Welcome to our library! We are dedicated to providing a wide range of books and resources for our community. Our library offers a diverse collection of books, magazines, newspapers, and digital resources for all ages and interests.
        </p>
        <p>
            Our mission is to promote literacy, education, and lifelong learning. We strive to create a welcoming and inclusive environment where everyone can explore, discover, and grow.
        </p>
        <p>
            Visit us today and embark on a journey of knowledge and imagination. Our friendly staff is ready to assist you in finding the perfect book or resource for your needs. We also host various events and programs, so be sure to check our calendar for upcoming activities.
        </p>
       
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\librarry\resources\views/about.blade.php ENDPATH**/ ?>