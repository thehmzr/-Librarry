<!--  -->

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2><?php echo e($book->title); ?></h2>
        <p><strong>Author:</strong> <?php echo e($book->author); ?></p>
        <a href="<?php echo e(url('/books')); ?>" class="btn btn-primary">Back</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\libr\resources\views/books/show.blade.php ENDPATH**/ ?>