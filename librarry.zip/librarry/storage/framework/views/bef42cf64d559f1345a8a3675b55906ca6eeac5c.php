<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Library Management System</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
 <style>
  body {
  padding-top: 60px;
  background-color: #00FFFF;
}

.jumbotron {
  background-color: #f8f9fa;
}

.navbar {
  background-color: #343a40;
}

.navbar-brand {
  font-size: 1.5rem;
}

.navbar-dark .navbar-nav .nav-link {
  color: #fff;
}

.card {
  height: 100%;
}

.card-body {
  text-align: center;
}

.card-title {
  font-size: 1.5rem;
}

.card-text {
  font-size: 2rem;
}

  </style>
</head>

<body>
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Library Management System</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="#">Dashboard</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('books.index')); ?>">Show/edit Books</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('books.create')); ?>">Add Books</a>
        </li>
       
        
      </ul>
    </div>
  </nav>

  <!-- Dashboard -->
  <div class="container mt-4">
    <h1>Welcome to the Library Management System!</h1>
    
  </div>

  <!-- Homepage -->
  <div class="jumbotron text-center">
    <h1 class="display-4">Welcome to the Library Management System</h1>
    <p class="lead">Manage your library with ease.</p>
    <hr class="my-4">
    <p>Explore the system features and start managing your books and members.</p>
    <a class="btn btn-primary btn-lg" href="#" role="button">Get Started</a>
  </div>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <script>
    document.addEventListener("DOMContentLoaded", function() {
  // Counter for total members
  var totalMembers = 0;
  var totalMembersElement = document.getElementById("totalMembers");
  
  // Counter for total books
  var totalBooks = 0;
  var totalBooksElement = document.getElementById("totalBooks");

  // Update counters every second
  setInterval(function() {
    totalMembers++;
    totalBooks++;
    totalMembersElement.innerText = totalMembers;
    totalBooksElement.innerText = totalBooks;
  }, 10);
});

    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\librarry\resources\views/books/home.blade.php ENDPATH**/ ?>